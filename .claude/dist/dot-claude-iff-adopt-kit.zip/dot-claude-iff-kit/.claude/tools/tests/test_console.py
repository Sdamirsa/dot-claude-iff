#!/usr/bin/env python3
"""test_console.py - tests for consolectl.py, console.py and console.template.html.

Run with: python3 -m unittest discover -s .claude/tools/tests -t .claude/tools -v
"""

from __future__ import annotations

import http.client
import json
import re
import shutil
import sys
import threading
import unittest
import unittest.mock as mock
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _fixture import FixtureCase, CLAUDE_DIR  # noqa: E402  (path must be set first)

import _lib  # noqa: E402
import consolectl  # noqa: E402

CONSOLE_DIR = CLAUDE_DIR / "console"
if str(CONSOLE_DIR) not in sys.path:
    sys.path.insert(0, str(CONSOLE_DIR))
import console  # noqa: E402  (path must be set first)

ZERO_TOKENS = {"input": 0, "output": 0, "cache_read": 0, "cache_creation": 0}


def _install_template(case: FixtureCase) -> None:
    """_fixture.py's scaffold makes a `console/` dir but does not seed it with the real
    template (it is not a config file) - tests that call build()/render() need it present,
    so copy the repo's actual template in rather than inventing a stand-in that could drift
    from what build() really ships."""
    src = CLAUDE_DIR / "console" / "console.template.html"
    shutil.copy(src, case.root / ".claude" / "console" / "console.template.html")


class PayloadEmptyProjectTests(FixtureCase):
    """1. payload() on a brand-new project with no state files at all."""

    def test_payload_does_not_raise_and_degrades_to_nulls(self):
        data = consolectl.payload()  # must not raise

        self.assertEqual(data["v"], 1)
        self.assertIsInstance(data["generated_at"], str)
        self.assertIsNone(data["server_ts"])
        self.assertEqual(data["mode"], "static")

        self.assertEqual(data["project"]["name"], self.root.name)
        # root is deliberately null: the payload is baked into a committed file, and a
        # machine's home path does not belong in a repo. file:// links derive the root
        # from the page's own location instead.
        self.assertIsNone(data["project"]["root"])

        now = data["now"]
        self.assertEqual(now["heartbeat"], {"ts": None, "note": None})
        self.assertIsNone(now["heartbeat_age_seconds"])
        self.assertIsNone(now["resume_pointer"])
        self.assertIsNone(now["phase"])
        self.assertIsNone(now["session_id"])
        self.assertEqual(now["open_loops"], [])
        self.assertEqual(now["in_flight"], [])
        self.assertEqual(now["needs_human"], {
            "open": 0,
            "by_band": {"SEV0": 0, "SEV1": 0, "SEV2": 0, "SEV3": 0},
            "top": [],
        })
        self.assertEqual(now["journal_tail"], [])
        self.assertEqual(now["lifecycle"], {
            "mode": "freestyle", "mode_label": "Freestyle", "mode_set": False,
            "organised": False, "phase": None, "phase_label": None, "phase_since": None,
            "contract": [],
        })

        tok = data["tokens"]
        self.assertIsNone(tok["as_of"])
        self.assertEqual(tok["today"], ZERO_TOKENS)
        self.assertEqual(tok["total"], ZERO_TOKENS)
        self.assertIsNone(tok["cost_usd"])
        self.assertFalse(tok["cost_known"])
        self.assertEqual(tok["unknown_models"], [])

        work = data["work"]
        self.assertEqual(work["tasks"], [])
        self.assertEqual(work["proposals"], {"open": 0, "resolved": 0, "items": []})
        self.assertEqual(work["log_tail"], [])
        self.assertEqual(work["watch_outs"], [])
        self.assertEqual(work["research"], [])

        self.assertIsNone(data["map"])
        self.assertIsNone(data["story"])
        # The MAP tab's Context list: no map yet, so an empty list and zero findings, never
        # a missing key the template would have to guess around.
        self.assertEqual(data["context"]["entries"], [])
        self.assertEqual(data["context"]["findings"], {"fail": 0, "warn": 0})
        self.assertEqual(data["context"]["always_on_lines"], 0)

        self.assertEqual(data["freshness"], {"live": ["now", "analysis", "work.proposals", "progress"],
                                             "ritual": ["tokens", "work.log_tail", "map", "story"]})
        # The Progress panel's model: no milestone is an honest one-line empty state.
        self.assertIn("no milestone yet", data["progress"]["empty"])
        self.assertEqual((data["progress"]["tasks"], data["progress"]["agents_in_flight"]), ([], []))

        self.assertIn("no heartbeat yet", data["warnings"])
        # The shipped default is billing "subscription", under which an empty price table is
        # the correct state, not a warning. The api-mode warning is covered in test_dist.
        self.assertNotIn("price table empty - costs read unknown", data["warnings"])
        self.assertEqual(data["tokens"]["billing"], "subscription")
        self.assertIn("map not built", data["warnings"])
        self.assertIn("story not built", data["warnings"])


class PayloadPopulatedTests(FixtureCase):
    """2. payload() picks up session/heartbeat/needs-human/journal/handshakes when present."""

    def setUp(self) -> None:
        super().setUp()
        state = self.root / ".claude" / "state"

        _lib.atomic_write_json(state / "heartbeat.json", {"ts": _lib.utc_now(), "note": "mid-task"})

        # Shapes below mirror statectl.py's real projections exactly (verified against
        # _build_session_projection / _build_needs_projection), not a guessed schema -
        # session_id and phase live under a nested "session" object, and needs-human.json
        # carries pre-computed "counts" plus an already band-sorted "tasks" list.
        _lib.atomic_write_json(state / "session.json", {
            "resume_pointer": "run the console tests next",
            "session": {"id": "sess-abc123", "phase": "check", "started": _lib.utc_now()},
            "open_loops": [
                {"id": "L1", "text": "finish console tab wiring", "status": "open"},
                {"id": "L2", "text": "old closed loop", "status": "closed"},
            ],
        })

        _lib.atomic_write_json(state / "needs-human.json", {
            "counts": {"open": 2, "resolved": 1, "by_band": {"SEV0": 1, "SEV1": 1, "SEV2": 0, "SEV3": 0}},
            "tasks": [
                {"id": "NH2", "title": "env is wedged", "category": "system-blocker", "band": "SEV0",
                 "blocks": 0, "note": "", "opened": _lib.utc_now(), "age_days": 0, "status": "open"},
                {"id": "NH1", "title": "pick a color", "category": "decide", "band": "SEV1",
                 "blocks": 0, "note": "", "opened": _lib.utc_now(), "age_days": 0, "status": "open"},
            ],
            "resolved_recent": [{"id": "NH3", "title": "already handled", "answer": "", "resolved": _lib.utc_now()}],
        })

        self.journal("pointer", text="run the console tests next")
        self.journal("task", id="T1", title="Build console", status="doing")
        self.journal("milestone", id="M1", title="consolectl payload() lands")

        (state / "handshakes").mkdir(parents=True, exist_ok=True)
        _lib.atomic_write_json(state / "handshakes" / "HS1.stub.json", {
            "agent": "console-builder", "task_id": "HS1", "dispatched_at": _lib.utc_now(),
        })

    def test_now_section_reflects_written_state(self):
        data = consolectl.payload()
        now = data["now"]

        self.assertIsNotNone(now["heartbeat"]["ts"])
        self.assertEqual(now["heartbeat"]["note"], "mid-task")
        self.assertIsInstance(now["heartbeat_age_seconds"], float)
        self.assertLess(now["heartbeat_age_seconds"], 30)

        self.assertEqual(now["resume_pointer"], "run the console tests next")
        self.assertEqual(now["phase"], "check")
        self.assertEqual(now["session_id"], "sess-abc123")

        self.assertEqual(now["open_loops"], [{"id": "L1", "text": "finish console tab wiring"}])

        nh = now["needs_human"]
        self.assertEqual(nh["open"], 2)
        self.assertEqual(nh["by_band"]["SEV0"], 1)
        self.assertEqual(nh["by_band"]["SEV1"], 1)
        self.assertEqual(nh["by_band"]["SEV2"], 0)
        ids = [item["id"] for item in nh["top"]]
        self.assertEqual(ids, ["NH2", "NH1"])  # projector's own band-first order, preserved
        self.assertNotIn("NH3", ids)  # only in resolved_recent, never read into needs_human
        self.assertEqual(nh["top"][0]["band"], "SEV0")

        summaries = [ev["summary"] for ev in now["journal_tail"]]
        self.assertIn("run the console tests next", summaries)
        self.assertIn("T1 · Build console · doing", summaries)
        self.assertIn("consolectl payload() lands", summaries)

        self.assertEqual(len(now["in_flight"]), 1)
        self.assertEqual(now["in_flight"][0]["agent"], "console-builder")
        self.assertEqual(now["in_flight"][0]["task_id"], "HS1")
        self.assertTrue(now["in_flight"][0]["dispatched_at"])


class InFlightEnvelopeTests(FixtureCase):
    """3. in_flight excludes a stub that already has a delivered envelope."""

    def test_stub_with_envelope_is_excluded(self):
        hs_dir = self.root / ".claude" / "state" / "handshakes"
        hs_dir.mkdir(parents=True, exist_ok=True)
        _lib.atomic_write_json(hs_dir / "HS1.stub.json", {"agent": "a1", "task_id": "HS1", "dispatched_at": _lib.utc_now()})
        _lib.atomic_write_json(hs_dir / "HS2.stub.json", {"agent": "a2", "task_id": "HS2", "dispatched_at": _lib.utc_now()})
        _lib.atomic_write_json(hs_dir / "HS2.json", {"agent_id": "a2", "task_id": "HS2", "status": "done", "artifacts": [], "notes": ""})

        data = consolectl.payload()
        task_ids = {item["task_id"] for item in data["now"]["in_flight"]}
        self.assertIn("HS1", task_ids)
        self.assertNotIn("HS2", task_ids)


class LifecycleAndProposalsTests(FixtureCase):
    """The mode/phase badge and the WORK tab's proposal box: payload keys read through the same
    _lib readers statectl and the SessionStart hook use, and a template that renders them."""

    def run_statectl(self, *argv):
        import contextlib
        import io
        import statectl
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            return statectl.main(list(argv))

    def test_badge_data_follows_the_journal(self):
        self.run_statectl("mode", "guided")
        self.run_statectl("phase", "build")
        life = consolectl.payload()["now"]["lifecycle"]
        self.assertEqual(life["mode"], "guided-solo")
        self.assertEqual(life["mode_label"], "Guided Solo")
        self.assertTrue(life["mode_set"])
        self.assertTrue(life["organised"])
        self.assertEqual(life["phase"], "build")
        self.assertEqual(life["phase_label"], "Build")
        self.assertTrue(life["phase_since"])
        self.assertEqual(life["contract"], _lib.phase_contract("build"))
        self.assertTrue(life["contract"])

    def test_a_malformed_phases_config_degrades_instead_of_raising(self):
        self.run_statectl("mode", "guided")
        self.run_statectl("phase", "build")
        self.write_config("phases", ["not", "an", "object"])
        life = consolectl.payload()["now"]["lifecycle"]  # must not raise
        self.assertEqual((life["phase"], life["phase_label"], life["contract"]), ("build", "Build", []))

    def test_freestyle_badge_carries_no_contract(self):
        self.run_statectl("phase", "deploy")
        life = consolectl.payload()["now"]["lifecycle"]
        self.assertEqual((life["mode"], life["phase"], life["contract"]), ("freestyle", "deploy", []))
        self.assertEqual(consolectl.payload()["mode"], "static",
                         "the top-level live/static mode is a different thing and stays put")

    def test_proposals_list_open_first_then_recent_resolved(self):
        self.run_statectl("proposal", "add", "plugin packaging", "--source", "issue#13")
        self.run_statectl("proposal", "add", "per-write scan", "--source", "agent:verifier", "--kind", "fix")
        self.run_statectl("proposal", "resolve", "PR-1", "--as", "planned", "--note", "in M2")
        props = consolectl.payload()["work"]["proposals"]
        self.assertEqual((props["open"], props["resolved"]), (1, 1))
        self.assertEqual([p["id"] for p in props["items"]], ["PR-2", "PR-1"])
        self.assertEqual(props["items"][0], {"id": "PR-2", "text": "per-write scan",
                                             "source": "agent:verifier", "kind": "fix",
                                             "status": "open", "note": ""})
        self.assertEqual(props["items"][1]["status"], "planned")
        self.assertEqual(props["items"][1]["note"], "in M2")

    def test_journal_tail_summarises_the_dials(self):
        self.run_statectl("mode", "fableous")
        self.run_statectl("phase", "plan")
        summaries = [ev["summary"] for ev in consolectl.payload()["now"]["journal_tail"]]
        self.assertIn("Fableous Orchestrated", summaries)
        self.assertIn("unset -> plan", summaries)

    def test_template_renders_the_badge_and_the_list(self):
        template = (CONSOLE_DIR / "console.template.html").read_text(encoding="utf-8")
        self.assertIn('id="lifecycle-badge"', template)
        self.assertIn('id="mode-badge"', template, "the live/static badge stays its own element")
        for key in (".lifecycle", ".mode_label", ".phase_label", ".contract", ".organised",
                    "work.proposals", "proposal resolve "):
            self.assertIn(key, template, key)
        _install_template(self)
        self.run_statectl("proposal", "add", "an idea", "--source", "human")
        result = consolectl.build()  # renders end to end with the new keys present
        self.assertIn("lifecycle-badge", result["path"].read_text(encoding="utf-8"))


class ProgressPanelTests(FixtureCase):
    """The NOW tab's Progress panel (T12): payload key `progress` IS progress.compute(), the model
    `statectl progress` prints, live on the existing poll, honest when empty, a snapshot when
    static, and never a reason to rewrite console.html when only the clock moved."""

    def setUp(self) -> None:
        super().setUp()
        _install_template(self)

    def populate(self) -> None:
        self.journal("mode", value="fableous-orchestrated")
        self.journal("milestone", id="M1", title="the long run")
        self.journal("phase", value="build")
        self.journal("task", id="T1", title="first", status="done", milestone="M1")
        self.journal("task", id="T2", title="second", status="doing", milestone="M1")
        (self.root / ".claude" / "tasks" / "t2.md").write_text(
            "# Task: T2 - second\n\n_Created 2026-10-05 · Status: doing_\n\n## Plan\n\n"
            "- [x] one\n- [ ] two\n", encoding="utf-8")
        _lib.atomic_write_json(_lib.stub_path("T2"), {"task_id": "T2", "agent": "builder",
                                                      "dispatched_at": _lib.utc_now(),
                                                      "worktree": ".claude/worktrees/t2"})

    def test_the_payload_key_is_the_one_model(self):
        import progress
        self.populate()
        data = consolectl.payload()
        self.assertIn("progress", data["freshness"]["live"])
        self.assertEqual(progress.without_clock(data["progress"]),
                         progress.without_clock(progress.compute()))
        pg = data["progress"]
        self.assertEqual(pg["milestone"]["id"], "M1")
        self.assertEqual([(t["id"], t["group"]) for t in pg["tasks"]],
                         [("T1", "done"), ("T2", "in progress")])
        self.assertEqual(pg["totals"]["percent"], 66, "T1 done = 1 of 1, T2 1 of 2: 2 of 3")
        self.assertEqual([a["task"] for a in pg["agents_in_flight"]], ["T2"])

    def test_a_milestone_with_no_tasks_is_one_line(self):
        self.journal("milestone", id="M9", title="nine")
        pg = consolectl.payload()["progress"]
        self.assertIn("milestone M9 has no tasks yet", pg["empty"])
        self.assertEqual(pg["tasks"], [])

    def test_the_in_flight_card_and_the_panel_agree(self):
        self.populate()
        self.assertEqual([f["task_id"] for f in consolectl.payload()["now"]["in_flight"]], ["T2"])
        envelope = {"agent_id": "builder-T2", "task_id": "T2", "status": "done", "agent": "builder",
                    "model": "opus", "files_changed": [], "needs_main": [],
                    "tests": [{"command": "x", "exit_code": 0, "summary": "ok"}]}
        _lib.atomic_write_json(_lib.envelope_path("T2", self.root / ".claude" / "worktrees" / "t2"), envelope)
        data = consolectl.payload()
        self.assertEqual(data["now"]["in_flight"], [], "a valid envelope in the worktree lands it")
        self.assertEqual(data["progress"]["agents_in_flight"], [])
        self.assertTrue(data["progress"]["tasks"][1]["has_valid_envelope"])

    def test_a_model_that_cannot_compute_degrades_honestly(self):
        import progress
        original = progress.compute
        progress.compute = lambda: (_ for _ in ()).throw(RuntimeError("boom"))
        try:
            data = consolectl.payload()  # must not raise
        finally:
            progress.compute = original
        self.assertIn("progress model unavailable", data["progress"]["empty"])
        self.assertEqual(data["now"]["in_flight"], [], "the in-flight card falls back to the stubs")

    def test_only_the_clock_moving_does_not_rewrite_the_page(self):
        import progress
        self.populate()
        later = progress._now
        try:
            progress._now = lambda: 2_000_000_000.0
            first = consolectl.build()
            progress._now = lambda: 2_000_000_000.0 + 3600
            second = consolectl.build()
            self.assertFalse(second["wrote"], "ages moved, nothing else: console.html stays put")
            self.journal("task", id="T2", status="blocked")
            third = consolectl.build()
        finally:
            progress._now = later
        self.assertTrue(first["wrote"])
        self.assertTrue(third["wrote"], "a real change still rewrites")

    def test_static_and_demo_builds_carry_the_snapshot(self):
        self.populate()
        for kwargs in ({}, {"demo": True, "out": "docs/demo/console.html"}):
            with self.subTest(build=kwargs):
                result = consolectl.build(**kwargs)
                embedded = consolectl._extract_embedded_data(result["path"].read_text(encoding="utf-8"))
                self.assertEqual(embedded["progress"]["milestone"]["id"], "M1")
                self.assertEqual(embedded["progress"]["tasks"][1]["in_flight"]["agent"], "builder")

    def test_the_template_renders_the_panel_from_the_model(self):
        template = (CONSOLE_DIR / "console.template.html").read_text(encoding="utf-8")
        for needle in ("function renderProgress", 'id: "progress-panel"', "DATA.progress",
                       'sectionHead("Progress", "progress")', "renderProgress(panel);",
                       ".checklist_done", ".checklist_total", ".has_valid_envelope", ".in_flight",
                       ".agents_in_flight", ".needs_human", ".last_activity", ".percent", ".basis",
                       ".tasks_done", ".tasks_total", ".milestone", ".group", ".empty", ".elapsed",
                       ".proposals_open", ".mode_label"):
            self.assertIn(needle, template, needle)
        body = template[template.index("function renderProgress"):template.index("function renderNow")]
        for timer in ("setTimeout", "setInterval", "fetch("):
            self.assertNotIn(timer, body, "the panel rides the existing poll: no timer of its own")
        self.assertEqual(template.count("appendNeedItem("), 3,
                         "one needs-human renderer, used by the Needs human card and the panel")
        self.assertIn('beat.note === "working"', template, "working pulse versus turn ended")
        self.assertLess(template.index("renderProgress(panel);"), template.index('sectionHead("Heartbeat"'),
                        "the panel sits at the top of NOW")


class BuildWriteGatingTests(FixtureCase):
    """4. build() write-gating: identical inputs produce identical bytes apart from
    generated_at - which build() achieves by mirroring statectl._write_gated's contract
    (skip the write entirely when nothing but generated_at would change), not merely by
    happening to serialize deterministically."""

    def setUp(self) -> None:
        super().setUp()
        _install_template(self)

    def test_second_build_with_no_source_change_is_byte_identical(self):
        with mock.patch.object(_lib, "utc_now", return_value="2030-01-01T00:00:00Z"):
            result1 = consolectl.build()
        self.assertTrue(result1["wrote"])
        first = result1["path"].read_text(encoding="utf-8")

        with mock.patch.object(_lib, "utc_now", return_value="2030-01-01T00:05:00Z"):
            result2 = consolectl.build()
        second = result2["path"].read_text(encoding="utf-8")

        self.assertFalse(result2["wrote"], "an unchanged payload must not rewrite console.html")
        self.assertEqual(first, second, "console.html changed even though nothing but the clock did")

    def test_a_real_source_change_does_rewrite(self):
        consolectl.build()
        state = self.root / ".claude" / "state"
        _lib.atomic_write_json(state / "heartbeat.json", {"ts": _lib.utc_now(), "note": "now working"})
        result = consolectl.build()
        self.assertTrue(result["wrote"], "a genuine source change must rewrite console.html")


class RenderedHtmlOfflineTests(FixtureCase):
    """5. no external resource references; exactly one __CONSOLE_DATA__ replacement."""

    def setUp(self) -> None:
        super().setUp()
        _install_template(self)

    def test_no_external_resource_references(self):
        result = consolectl.build()
        html = result["path"].read_text(encoding="utf-8")

        self.assertNotIn(consolectl.TEMPLATE_TOKEN, html)

        # The offline guarantee is about what the page FETCHES, not what it links to: script
        # src=, stylesheet link href=, css url(), and fetch() to a remote host would each make
        # the page depend on the network. A plain <a href> navigation anchor (the footer's
        # derived repo/tour/guide links) fetches nothing until a human clicks it, and is
        # allowed. The SVG namespace URI is a name, never a locator, and never fetched.
        fetchable = re.findall(
            r'(?:\bsrc\s*=\s*["\']https?://|<link[^>]{0,200}href\s*=\s*["\']https?://'
            r'|url\(\s*["\']?https?://|fetch\(\s*["\']https?://)',
            html,
        )
        self.assertEqual(fetchable, [], "the console must fetch nothing external")

        data = consolectl.payload()
        rendered = consolectl.render(data)
        self.assertEqual(rendered.count(consolectl.TEMPLATE_TOKEN), 0)
        marker = "const DATA = "
        idx = rendered.index(marker) + len(marker)
        parsed, _end = json.JSONDecoder().raw_decode(rendered[idx:])
        self.assertEqual(parsed, data)


class ServerTests(FixtureCase):
    """6. the hardened server: live payload, Host-header check, traversal defence."""

    def setUp(self) -> None:
        super().setUp()
        self.server = console.make_server("127.0.0.1", 0)
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=5)
        super().tearDown()

    def _get(self, path: str, host_header: str | None = None):
        conn = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            headers = {"Host": host_header} if host_header else {}
            conn.request("GET", path, headers=headers)
            resp = conn.getresponse()
            body = resp.read()
            return resp.status, body
        finally:
            conn.close()

    def test_live_console_json(self):
        status, body = self._get("/live/console.json")
        self.assertEqual(status, 200)
        data = json.loads(body.decode("utf-8"))
        self.assertEqual(data["mode"], "live")
        self.assertIsNotNone(data["server_ts"])

    def test_bad_host_header_is_rejected(self):
        status, _body = self._get("/live/console.json", host_header="evil.example")
        self.assertEqual(status, 403)

    def test_path_traversal_does_not_escape_console_dir(self):
        # policy.json is a real, shipped file, but it is not in read_allowlist and lives
        # outside console/ - a correct containment check must refuse it regardless of the
        # traversal sequence used to reach it.
        status, body = self._get("/../config/policy.json")
        self.assertNotEqual(status, 200)
        self.assertNotIn(b"fallback_protected", body)


class CLIVerdictTests(FixtureCase):
    """Every consolectl.py command prints exactly one <TAG>_OK|WARN|FAIL token (the same
    convention test_statectl.TestVerdictAndUsage enforces for statectl.py's commands),
    and `payload`'s stdout stays pure JSON - the token goes to stderr instead."""

    def setUp(self) -> None:
        super().setUp()
        _install_template(self)

    def _run(self, *argv):
        import io
        import contextlib
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            code = consolectl.main(list(argv))
        return code, out.getvalue(), err.getvalue()

    def _assert_exactly_one_token(self, combined: str):
        tokens = [t for t in ("CONSOLE_OK", "CONSOLE_WARN", "CONSOLE_FAIL") if t in combined]
        self.assertEqual(len(tokens), 1, f"expected exactly one verdict token, got {tokens} in: {combined!r}")

    def test_build_prints_one_verdict_token(self):
        code, out, err = self._run("build")
        self.assertEqual(code, 0)
        self._assert_exactly_one_token(out + err)

    def test_payload_stdout_is_pure_json_verdict_on_stderr(self):
        code, out, err = self._run("payload")
        self.assertEqual(code, 0)
        json.loads(out)  # must parse cleanly - no verdict token mixed into stdout
        self._assert_exactly_one_token(err)

    def test_open_prints_one_verdict_token(self):
        code, out, err = self._run("open")
        self.assertEqual(code, 0)
        self._assert_exactly_one_token(out + err)


class PortDerivationTests(FixtureCase):
    """Port "auto" derives from the folder name: stable, in range, and never one shared
    default for every adoption on a machine. An explicit port stays a decided-once value."""

    def test_explicit_integer_wins(self):
        self.assertEqual(_lib.console_port({"port": 7300}), 7300)
        self.assertEqual(_lib.console_port({"port": "7301"}), 7301)

    def test_auto_and_absent_derive_the_same_stable_port(self):
        a = _lib.console_port({"port": "auto"})
        b = _lib.console_port({})
        self.assertEqual(a, b)
        self.assertTrue(7100 <= a <= 7899, f"derived port {a} out of the documented range")

    def test_hostname_is_sanitized_folder_name(self):
        name = _lib.console_hostname()
        self.assertRegex(name, r"^[a-z0-9-]+\.localhost$")

    def test_auto_walks_past_a_collision(self):
        cfg = dict(_lib.load_config("console"), port="auto")
        self.write_config("console", cfg)
        base = _lib.console_port(cfg)
        try:
            blocker = console.make_server("127.0.0.1", base)
        except OSError:
            self.skipTest(f"derived port {base} already taken on this machine")
        try:
            server = console.bind_server("127.0.0.1", cfg, None)
            try:
                self.assertEqual(server.server_address[1], base + 1)
            finally:
                server.server_close()
        finally:
            blocker.server_close()

    def test_explicit_config_port_still_fails_loudly(self):
        blocker = console.make_server("127.0.0.1", 0)
        port = blocker.server_address[1]
        cfg = dict(_lib.load_config("console"), port=port)
        self.write_config("console", cfg)
        try:
            with self.assertRaises(OSError):
                console.bind_server("127.0.0.1", cfg, None)
        finally:
            blocker.server_close()

    def test_folder_localhost_host_header_is_allowed_and_others_stay_refused(self):
        server = console.make_server("127.0.0.1", 0)
        port = server.server_address[1]
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            for host_header, expected in (
                    (f"anything.localhost:{port}", 200),
                    (f"evil.example.com:{port}", 403)):
                with self.subTest(host=host_header):
                    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
                    conn.request("GET", "/live/console.json", headers={"Host": host_header})
                    res = conn.getresponse()
                    res.read()
                    conn.close()
                    self.assertEqual(res.status, expected)
        finally:
            server.shutdown()
            server.server_close()


class SystemEndpointTests(FixtureCase):
    """/live/system.json is opt-in and live-only: 404 when the monitor is off (nothing to
    distinguish it from a route that does not exist), a fresh sample when on."""

    def _serve(self):
        server = console.make_server("127.0.0.1", 0)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        return server, server.server_address[1]

    def _get(self, port: int, path: str):
        conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
        conn.request("GET", path)
        res = conn.getresponse()
        body = res.read()
        conn.close()
        return res.status, body

    def test_disabled_monitor_is_a_404(self):
        cfg = dict(_lib.load_config("console"), monitor={"enabled": False})
        self.write_config("console", cfg)
        server, port = self._serve()
        try:
            status, _body = self._get(port, "/live/system.json")
            self.assertEqual(status, 404)
        finally:
            server.shutdown()
            server.server_close()

    def test_enabled_monitor_serves_a_sample(self):
        cfg = dict(_lib.load_config("console"), monitor={"enabled": True})
        self.write_config("console", cfg)
        server, port = self._serve()
        try:
            status, body = self._get(port, "/live/system.json")
            self.assertEqual(status, 200)
            sample = json.loads(body)
            for key in ("os", "cpu_percent", "load1", "ram", "gpu"):
                self.assertIn(key, sample)
        finally:
            server.shutdown()
            server.server_close()


class SysmonTests(unittest.TestCase):
    def test_snapshot_never_raises_and_keeps_its_shape(self):
        import sysmon
        sample = sysmon.snapshot(interval=0.05)
        self.assertEqual(set(sample), {"os", "cpu_percent", "load1", "ram", "gpu"})
        if sample["ram"] is not None:
            self.assertIn("total", sample["ram"])
            self.assertIsInstance(sample["ram"]["total"], int)
        if sample["gpu"] is not None:
            self.assertIn("vram_total", sample["gpu"])


class PortCollisionTests(FixtureCase):
    """Port 7717 shipped as every project's default, so the second adoption on one machine
    lost the bind every session - silently, because the failure went only to a log nobody
    reads. A refused bind must be loud and name the one-line fix."""

    def test_bind_failure_exits_with_a_named_fix(self):
        import contextlib
        import io
        blocker = console.make_server("127.0.0.1", 0)
        port = blocker.server_address[1]
        try:
            err = io.StringIO()
            with contextlib.redirect_stderr(err):
                code = console.main(["--port", str(port)])
            self.assertEqual(code, 2)
            self.assertIn("CONSOLE_FAIL", err.getvalue())
            self.assertIn("console.json", err.getvalue(),
                          "the failure message must name where the port is decided")
        finally:
            blocker.server_close()



if __name__ == "__main__":
    unittest.main()
