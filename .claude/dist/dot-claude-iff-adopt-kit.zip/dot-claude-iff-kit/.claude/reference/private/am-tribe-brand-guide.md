# am-tribe - Brand Guide (full, private copy)

Stored gitignored under .claude/reference/private/ for local reuse across projects.
The committed, softly-adopted subset for this repo lives at .claude/reference/brand-identity.md.

---

## Brand Philosophy

**Mottos:**
- "am-tribe - Ascended Mankind tribe."
- "Good unite hearts, cover all, break none."

**Narrative arc:** Person -> People -> Purpose

| Pillar | Section | Meaning |
|---|---|---|
| Amir | Portfolio + Unfiltered | The person - credibility, story, work, authenticity |
| Tribe | Members + Resources | The people - mentees, peers, mentors, PIs, community |
| Thrive | Tools + Cools + Schools | The mission - apps, visuals, and learning that help the world |

**Core values:** Inclusive (diverse people, English + Persian, accessible tools) · Warm
(friendly, human, approachable, not cold-tech) · Authentic ("unfiltered" is a section name for
a reason) · Purposeful (everything exists to help someone grow).

**Logo story:** The spiral is inspired by the Naruto leaf symbol - breaking cycles of hatred.
The moon shows imperfection within perfection, and the path toward goodness that seems
unreachable - but the mountain beneath it is reachable. Diverse people within the spiral do
different things, all in harmony. Colors: ocean blue, earth green, moon amber.

## Color Palette (light theme only, no dark mode)

Background and neutrals: page #FAF9F6 (warm off-white) · surface #FFFFFF · heading #0F172A ·
body #1E293B · muted #64748B · borders #E2E8F0 · hover bg #F1F5F9.

Brand colors, one per section, used with intention:
- Ocean Blue #2563EB (blue-600): links, buttons, active nav, primary CTAs - Amir. 80% of colored UI.
- Earth Green #059669 (emerald-600): tags, success, growth - Tribe. 12%.
- Moon Amber #D97706 (amber-600): highlights, featured, warm callouts - Thrive. 8%.

Lighter variants: blue-100 #DBEAFE · emerald-100 #D1FAE5 · amber-100 #FEF3C7.

## Typography

font-family: "Nunito", "Vazirmatn", sans-serif; code: JetBrains Mono.
Nunito for all text (rounded terminals, friendly, warm; weights 200-900). Vazirmatn as the
Persian fallback (browser auto-selects for Persian characters). Google Fonts loading:
Nunito:wght@300;400;600;700;800 · Vazirmatn:wght@400;700 · JetBrains+Mono:wght@400.

Type scale: h1 800 text-4xl/5xl (one per page) · h2 700 text-2xl/3xl · h3 600 text-xl ·
body 400 16px · caption 400 14px · code 400 14px.

## Spacing and density

Between balanced and airy. Section gaps py-16..py-20 · px-6 horizontal · max-w-5xl pages ·
max-w-prose (~65ch) for posts · cards p-6..p-8 · grid gap-6 · leading-relaxed body · navbar py-4 px-6.

## Site map and navigation

/ landing (EnsoHero, TribePhilosophy) · /portfolio · /unfiltered(/[slug]) ·
/tribe(/members,/resources) · /thrive(/tools,/cools,/schools(/[slug]),/[slug]).
Nav: [logo] Thrive(Cools/Tools/Schools) · Tribe · Amir(Portfolio/Unfiltered).
Footer: two columns (Explore + Connect) with fixed mottos.

## Section color-coding

Amir = Ocean Blue · Tribe = Earth Green · Thrive = Moon Amber - subtle accent details only
(active nav indicator, links, card accents), never full-page color changes.

## Tribe Philosophy

"am-tribe" = "Ascended Mankind tribe." After four thousand years of civilization, humanity's
accumulated power now threatens to consume its creators. The only path forward is unity:
seeing all humans, all living beings, and the Earth itself as one tribe. Each person IS the
whole tribe: "I am-tribe" - where "I" refers to all of us. The paradox: evolution may have
wired us for tribalism, but the new civilization requires expanding that instinct to all of
humanity. The only good is what brings all humans together - across every time frame, without
exception, without justification for misalignment.

## Persian Carpet palette (TribePhilosophy component)

Burgundy #6B1D2A (carpet field) · Cream #F5F0E1 (boteh fill) · Teal #2D6A6A · Gold #C4A35A ·
Forest #2D5F3E · Rose #C4586A · Navy #1E3A5F.

## Assets checklist

logo.png 512+ · icon.png 512+ · favicon.ico 32 · apple-icon 180 · og-image 1200x630 ·
amir.jpg 400+ square.

## Future (not now)

Tribe auth (Spiral 5) · short URL redirects · Persian RTL pages · print stylesheet.
