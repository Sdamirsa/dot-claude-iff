# STATUS

_Rewritten by `/project-memory`. Read this first, every session._

## Current focus

Adoption in progress: this .claude system was just unzipped and has not been adapted to this
project yet. Follow START-HERE.md, then delete this sentence during the first ritual.

## Active tasks

- none yet

## Next steps

1. Open Claude Code here and finish the adoption (see START-HERE.md).
2. Fill CLAUDE.md's placeholders from this repo's reality.
3. Run the first /project-memory.

## Blockers / open decisions

- none

## Watch-outs

- none yet: lessons are earned, not inherited
