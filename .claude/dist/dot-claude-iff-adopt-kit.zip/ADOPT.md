# Adopt dot-claude-iff into an existing repo

This kit installs a .claude operating system: one place to interact (Claude Code), one place
to control (a live console), one command to evolve (/project-memory). Your existing files are
merged, never overwritten; an existing .claude/ is the designed case, not a problem.

1. Unzip this kit anywhere OUTSIDE the repo you want to adopt into (for example next to it).
2. Open Claude Code in YOUR repo.
3. Paste this to the agent (adjust the path):

   > Adopt the dot-claude-iff system from <path-to>/dot-claude-iff-kit into this repo.
   > Follow <path-to>/dot-claude-iff-kit/.claude/skills/adopt/SKILL.md end to end. This
   > repo may already have a .claude directory: merge, never overwrite, and report every
   > conflict to me.

4. When Claude Code asks whether to trust the newly installed hooks, say yes; the adopt
   skill's verify phase probes that they actually fire.

The kit is a complete, self-seeding copy of the system; after adoption, your repo can itself
be the source for the next adoption. The manual ships at .claude/README.md.
