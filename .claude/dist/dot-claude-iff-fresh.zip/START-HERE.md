# Start here

You unzipped the dot-claude-iff system into a fresh repo. One session sets it up:

1. `git init` if you have not already (the system assumes a git repo).
2. Open Claude Code in this directory. When it asks whether to trust this project's hooks,
   say yes: the hooks are the heartbeat, the capture lane, the policy gate and the ritual
   ticket, and without trust they silently do not run.
3. Type this as your prompt, starting with /adopt (typing the command yourself is what lets
   the system's ritual run: the agent cannot open it on its own):

   > /adopt Finish adopting the dot-claude-iff system into this repo. The files are already
   > installed, so skip the copy phase: run phases 2 (frame questions), the visibility step
   > at the end of 3 (record the answer, apply the .gitignore block), 4 (adapt: fill
   > CLAUDE.md's placeholders from this repo, reset STATUS to reality), 5 (verify, including
   > the hooks-fire probe) and 6 (first ritual) against this repo.

4. Open the console beside your terminal: `python3 .claude/console/console.py` prints your
   URL (http://<your-folder-name>.localhost:<derived-port>/console.html - the port derives
   from the folder name, so projects never fight over one default). Half the screen for it,
   half for Claude Code; every session start prints the URL again.

What you get: one place to interact (Claude Code), one place to control (the console), one
command to evolve (/project-memory). The manual is .claude/README.md.
