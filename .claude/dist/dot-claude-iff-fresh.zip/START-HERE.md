# Start here

You unzipped the dot-claude-iff system into a fresh repo. One session sets it up:

1. `git init` if you have not already (the system assumes a git repo).
2. Open Claude Code in this directory. When it asks whether to trust this project's hooks,
   say yes: the hooks are the heartbeat, the capture lane and the policy gate, and without
   trust they silently do not run.
3. Paste this to the agent:

   > Finish adopting the dot-claude-iff system into this repo. The files are already
   > installed, so skip the copy phase: read .claude/skills/adopt/SKILL.md and run its
   > phases 2 (frame questions), 4 (adapt: fill CLAUDE.md's placeholders from this repo,
   > reset STATUS to reality), 5 (verify, including the hooks-fire probe) and 6 (first
   > ritual) against this repo.

4. Open the console beside your terminal: `python3 .claude/console/console.py`, then
   http://127.0.0.1:7717/console.html - half the screen for it, half for Claude Code.

What you get: one place to interact (Claude Code), one place to control (the console), one
command to evolve (/project-memory). The manual is .claude/README.md.
